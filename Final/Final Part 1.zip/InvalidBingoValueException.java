/**
 * 
 */

/**
 * @author wernerla
 *
 */
public class InvalidBingoValueException extends Exception {

	/**
	 * 
	 */
	public InvalidBingoValueException() {
		// TODO Auto-generated constructor stub
		super("Value must be in the correct range for the column");
	}

}
