/**
 * 
 */

/**
 * @author wernerla
 *
 */
public class InvalidCardException extends RuntimeException {

	/**
	 * 
	 */
	public InvalidCardException(String reason) {
		// TODO Auto-generated constructor stub
		super(reason);

	}

}
