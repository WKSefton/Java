/** 
 *  Name: William Sefton
 *  Instructor: Laurie Werner 
 *  Partner: None 
 *  CSE 271 HA 
 *  DateTest tests all methods for the Date class
 */

/**
 * @author wernerla
 *
 */
import java.util.*;
public class DateTest {
  
  /**
   * @param args
   */
  public static void main(String[] args) {
    //Date myDate1 = new Date(7, 24, 1958);
    //Date myDate2 = new Date(3, 12, 2017);
    // testing toString
    //System.out.println(myDate1.toString());
    
    
    
    //Add testing here
    //Be sure to attempt setting at least three bad dates.
    //Comment them out before you turn in your assignment.
    
    //bad day
    //try{
    //Date myDate3 = new Date(7, 40, 1958);
    //}catch(Exception e) { System.out.println(e.getMessage()); }
    //bad month
    //try{
    //Date myDate4 = new Date(15, 24, 1958);
    //}catch(Exception e) { System.out.println(e.getMessage()); }
    //bad year
    //try{
    //Date myDate5 = new Date(2, 29, 2005);
    //}catch(Exception e) { System.out.println(e.getMessage()); }
    
    //test calcNumDays
    //System.out.println("There are: " + myDate1.calcNumDays(myDate2) + " days between " + myDate2.toString() + " and " + myDate1.toString());
    //test calcNumDays error
    //try{
    //System.out.println(myDate2.calcNumDays(myDate1));
    //}catch(Exception e)
    //{
    // System.out.println(e.getMessage()); 
    //}
    
    //test setter method
    //myDate2.setDate(7,24,1958);
    
    //test equals method
    //System.out.println("The dates " + myDate2.toString() + " and " + myDate1.toString() + " are the same? " + myDate2.equals(myDate1));
    
  }
  
}
