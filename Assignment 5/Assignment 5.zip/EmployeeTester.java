/** 
 *  Name: William Sefton
 *  Instructor: Laurie Werner 
 *  Partner: None 
 *  CSE 271 HA 
 *  EmployeeTester tests all the methods for the Employee class
 */

public class EmployeeTester
{
  public static void main(String[] args)
  {
    Date currentDate = new Date(3,14,2018);
    
    Date hireDateTest = new Date(3,10,1990);
    Employee test = new Employee("Will", "Sef", hireDateTest, 123); 
    
    Date hireDateTest1 = new Date(4,19,1965);
    Employee test1 = new Employee("Bill", "Turn", hireDateTest1, 1);
    
    Date hireDateTest2 = new Date(8,18,1982);
    Employee test2 = new Employee("Kim", "Morris", hireDateTest2, 12);
    
    Date hireDateTest3 = new Date(12,10,1993);
    Employee test3 = new Employee("Jake", "Lombert", hireDateTest3, 1234);
    
    //test toString
    System.out.println("\t*****Test Employees*****");
    System.out.println(test.toString());
    System.out.println(test1.toString());
    System.out.println(test2.toString());
    System.out.println(test3.toString());
    
    //test setter methods
     System.out.println("\t*****Test Setter Methods*****");
    test.setFirstName("Lisa");
    test.setLastName("Nublin");
    test.setEmpNumber(33);
    test.setHireDate(10,20,1998);
    System.out.println("\tChanges made to one employee");
    System.out.println(test.toString());
    
    //testing errors
    System.out.println("\t*****Testing Errors*****");
    try{
    test.setHireDate(14,20,1998);
    }catch(Exception e) { System.out.println(e.getMessage()); }
    
    //test getter methods
     System.out.println("\t*****Test Getter Methods*****");
    System.out.println("Employee ID: " + test1.getEmpNumber());
    System.out.println("Employee Name: " + test1.getFirstName() + " " + test1.getLastName());
    System.out.println("Employee Date Hired: " + test1.getHireDate());
   
    //test days hired method
    test1.daysHired(currentDate);
    
  }
  
}