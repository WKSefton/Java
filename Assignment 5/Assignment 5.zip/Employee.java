/** 
 *  Name: William Sefton
 *  Instructor: Laurie Werner 
 *  Partner: None 
 *  CSE 271 HA 
 *  Employee class creates an employee object with all the information
 * for an employee
 */

/**
 * @author wernerla
 * Starter file for Employee class construction assignment
 * CSE 271 
 */
public class Employee {

 private String firstName;
 private String lastName;
 private Date hireDate;
 private int empNumber;
 public static int MIN = 10000;
 public static int MAX = 100000;

 
 /**
  * constructor to initialize name, birth date and hire date. Exceptions are thrown if the dates are 
  * not valid.
  * @param firstName String representing the employee first name 
  * @param lastName String representing the employee last name 
  * @param hireDate  Date object for the employees first day 
  * @param empNumber Integer employee number
  */
 public Employee(String firstName, String lastName, Date hireDate, int empNumber)
 {
  this.firstName = firstName;
  this.lastName = lastName;
  this.hireDate = hireDate;
  
  empNumber = empNumber(empNumber);
  this.empNumber = empNumber;
 } 
 
 /**
  * calculates number of days from hire date
  * 
  * @param int current month
  * @param int current day
  * @param int current year
  */
 public void daysHired(int month, int day, int year)
 {
  Date current = new Date(month,day,year);
    
    System.out.println("Employee hired " + this.hireDate.calcNumDays(current) + " days.");
    System.out.println("From " + this.hireDate.toString() + " to " + current.toString());
 }
  /**
  * calculates number of days from hire date
  * 
  * @param Date current date
  */
 public void daysHired(Date current)
 {    
    System.out.println("Employee hired " + this.hireDate.calcNumDays(current) + " days.");
    System.out.println("From " + this.hireDate.toString() + " to " + current.toString());
 }
 
 /**
  * accessor method for first name
  * 
  * @return String First Name
  */
 public String getFirstName()
 {
  return this.firstName; 
 }
  /**
  * mutator method for first name
  * 
  * @param String First Name
  */
 public void setFirstName(String firstName)
 {
  this.firstName = firstName; 
 }
 /**
  * accessor method for last name
  * 
  * @return String Last Name
  */
 public String getLastName()
 {
  return this.lastName; 
 }
   /**
  * mutator method for last name
  * 
  * @param String Last Name
  */
 public void setLastName(String lastName)
 {
  this.lastName = lastName; 
 }
  /**
  * accessor method for Hire Date
  * 
  * @return String date of hire
  */
 public String getHireDate()
 {
  return this.hireDate.toString(); 
 }
   /**
  * mutator method for hire date
  * 
  * @param int month of hire
  * @param int day of hire
  * @param int year of hier
  */
 public void setHireDate(int month, int day, int year)
 {
  this.hireDate = new Date(month,day,year); 
 }
   /**
  * accessor method for employee number
  * 
  * @return int Employee Number
  */
 public int getEmpNumber()
 {
  return this.empNumber; 
 }
    /**
  * mutator method for employee number
  * 
  * @param int Employee Number
  */
 public void setEmpNumber(int empNumber)
 {
  empNumber = empNumber(empNumber);
  this.empNumber = empNumber; 
 }
 /**
  * private method to ensure employee number is 5 digits
  * 
  * @param int number
  */
 private int empNumber(int empNumber)
 {
   String number = Integer.toString(empNumber);
   while(number.length() < 5)
     number += "0";
   
   empNumber = Integer.parseInt(number);
   return empNumber;
   
 }
 
 /*  convert Employee to String format
  * @returns a sting with full name and hire date.
  */
 public String toString()
 {
  return String.format("%s, %s  ID: %d  Hired: %s ", 
    lastName, firstName, this.empNumber, hireDate);
 } 

}
