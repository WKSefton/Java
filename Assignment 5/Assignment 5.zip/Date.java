/** 
 *  Name: William Sefton
 *  Instructor: Laurie Werner 
 *  Partner: None 
 *  CSE 271 HA 
 *  Date class creates date objects and compaires if two dates
 * are equal also can calculate the number of days between two dates
 */

/**
 * 
 * @author wernerla
 * Date class for use in the Employee project.
 */
public class Date 
{
  
  private int month; // 1-12
  private int day; // 1-31 based on month
  private int year; // any year
  
  //int array of the number of days in a given month
  private static final int[] daysPerMonth = 
  {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  
  /**
   * @param month integer representing the month 1-12
   * @param day integer representing the number of days in the month
   * @param year integer representing the 4-digit year
   */
  public Date(int month, int day, int year)
  {
    // check if month in range
    this.checkMonthRange(month);
    // check if day in range for month
    this.checkDayRange(month, day);
    
    // check for leap year if month is 2 and day is 29
    this.checkLeapYear(month, day, year);
    
    this.month = month;
    this.day = day;
    this.year = year;
  }
  
  /**
   * checks to see if the month is between 1 and 12
   * 
   * @param month Month of the year
   */
  private void checkMonthRange(int month)
  {
    if (month <= 0 || month > 12)
      throw new IllegalArgumentException(
                                         "month (" + month + ") must be 1-12");
  }
  
  /**
   * checks to see if the day is in range
   * 
   * @param month int Month of the year
   * @param day int Day of the month
   */
  private void checkDayRange(int month, int day)
    
  {
    if (day <= 0 || 
        (day > daysPerMonth[month] && !(month == 2 && day == 29)))
      throw new IllegalArgumentException("day (" + day + 
                                         ") out-of-range for the specified month and year");
  }
  
  /**
   * checks to see if the year is a leap year
   * 
   * @param month int Month of the year
   * @param day int Day of the month
   * @param year int Year
   */
  private void checkLeapYear(int month, int day, int year)
  {
    if (month == 2 && day == 29 && !(year % 400 == 0 || 
                                     (year % 4 == 0 && year % 100 != 0)))
      throw new IllegalArgumentException("day (" + day +
                                         ") out-of-range for the specified month and year");
  }
  
  /**
   * returns true if the dates match
   * 
   * @overide
   * @return boolean true if dates are the same
   * false if dates are not the same
   */
  public boolean equals(Object o)
  {
    if (o == null || ! (o instanceof Date))
      return false;
    
    if (getClass() != o.getClass())
      return false;
    
    Date other = (Date) o;
    
    return this.day == other.day && this.month == other.month && this.year == other.year;
  }
  /**
   * Getter method for year
   * @return int Year
   */
  private int getYear()
  {
    return this.year; 
  }
  
  /**
   * Getter method for month
   * @return int Month of the year
   */
  private int getMonth()
  {
    return this.month; 
  }
  
  /**
   * Getter method for day
   * @return int Day of the month
   */
  private int getDay()
  {
    return this.day; 
  }
  
  // add setter method here
  /**
   * Setter method
   * 
   * @param month int Month of the year
   * @param day int Day of the month
   * @param year int Year
   */
  public void setDate(int month, int day, int year)
  {
    // check if month in range
    this.checkMonthRange(month);
    // check if day in range for month
    this.checkDayRange(month, day);
    
    // check for leap year if month is 2 and day is 29
    this.checkLeapYear(month, day, year);
    
    this.month = month;
    this.day = day;
    this.year = year;
  }
  
  /**
   * determin number of days between two date objects
   * 
   * @param aDate Date
   */
  public int calcNumDays(Date aDate)
  {
    if (this.year > aDate.year || (this.month > aDate.month && this.year == aDate.year) || ( this.year == aDate.year && this.month == aDate.month && this.day < aDate.day))
      throw new IllegalArgumentException("The date entered in the parameter happend before the date being compaired to.");
    
    int days = 0;
    
    days = ((aDate.year - this.year))*365;
    
    for(int i = 12; i == aDate.month; i--)
    {
      days -= daysPerMonth[i];
    }
    
    for(int i = 0; i == this.month; i++)
    {
      days -= daysPerMonth[i];
    }
    
    days += Math.abs(aDate.day - this.day);
    
    return days;
    
  }
  
  /* override the toString method
   * returns a String of the form month/day/year
   */
  public String toString()
  { 
    return String.format("%d/%d/%d", month, day, year); 
  } 
  
} // end class Date


